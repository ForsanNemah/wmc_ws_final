<?php

return [

   

    'main' => '
   Home
    ',




    
    'the_window' => '
  About Us
    ',


    
    
    'services' => '
     Our Services
    ',


    
    
    'work' => '
   Our Projects
    ',


    
    
    'call_us' => '
  Contact Us
    ',


];
