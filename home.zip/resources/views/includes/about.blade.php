
    
    
    <div id="about">
        @if (config('app.locale'=='ar'))
       
        <div class="about-area ptb-100">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-text">
                            <span>{{__("msg.who_is_us")}}</span>
                            <h3>{{__("msg.who_is_us_h")}} </h3>
                             
                            <p>
                                {{__("msg.who_is_us_h1")}}
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-img">
                            <img src="assets/img/about/about-img.jpg" alt="Image">
                            <div class="about-card">
                                <i class="las la-gem"></i>
                                <h3> <span> {{__("msg.more_than")}}</span>10</h3>
                                <p>{{__("msg.years_of_experince")}} </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
        @else
            
    
    
    
    
    
    
        <div class="about-area ptb-100">
            <div class="container" dir="ltr">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-text">
                            <span>{{__("msg.who_is_us")}}</span>
                            <h3>{{__("msg.who_is_us_h")}} </h3>
                             
                            <p>
                                {{__("msg.who_is_us_h1")}}
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-img">
                            <img src="assets/img/about/about-img.jpg" alt="Image">
                            <div class="about-card">
                                <i class="las la-gem"></i>
                                <h3> <span> {{__("msg.more_than")}}</span>10</h3>
                                <p>{{__("msg.years_of_experince")}} </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    
    
    
    
        @endif
        
        
        
    </div>
    
   