<div class="partner-area ptb-100">
    <div class="container">
        <div class="section-title">
            <h2>  <?php echo e(__("msg.our_work_web")); ?></h2>
        </div>
        <div class="partner-slider owl-carousel owl-theme">
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner1.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner2.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner3.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner4.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner5.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner6.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner7.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner8.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner9.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner10.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner11.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner12.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner13.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner14.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner15.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner16.png" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a href="#">
                    <img src="assets/img/partner/partner17.png" alt="logo">
                </a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp4\www\wmc_ws\resources\views/includes/web_stories.blade.php ENDPATH**/ ?>