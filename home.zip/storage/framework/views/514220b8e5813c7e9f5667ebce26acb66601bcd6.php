<div class="partner-area ptb-100">
    <div class="container">
        <div class="section-title">
            <h2> <?php echo e(__("msg.our_customers")); ?> </h2>
        </div>
        <div class="partner-slider owl-carousel owl-theme">
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner1.png"  class="simg"  alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a >
                    <img src="assets/img/partner/partner2.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner3.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner4.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner5.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner6.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner7.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner8.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner9.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner10.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner11.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner12.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner13.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a >
                    <img src="assets/img/partner/partner14.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner15.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner16.png" class="simg" alt="logo">
                </a>
            </div>
            <div class="partner-slider-item">
                <a  >
                    <img src="assets/img/partner/partner17.png" class="simg" alt="logo">
                </a>
            </div>
        </div>
    </div>
</div>


<style>


.simg {
  border: 1px solid #454;
  border-radius: 10px;
  padding: 5px;
 
}


</style><?php /**PATH C:\wamp4\www\wmc_ws\resources\views/includes/en/stories.blade.php ENDPATH**/ ?>