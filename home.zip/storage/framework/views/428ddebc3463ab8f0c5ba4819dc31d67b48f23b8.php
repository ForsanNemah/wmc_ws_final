
    
    
    <div id="about">
        <?php if(config('app.locale'=='ar')): ?>
       
        <div class="about-area ptb-100">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-text">
                            <span><?php echo e(__("msg.who_is_us")); ?></span>
                            <h3><?php echo e(__("msg.who_is_us_h")); ?> </h3>
                             
                            <p>
                                <?php echo e(__("msg.who_is_us_h1")); ?>

                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-img">
                            <img src="assets/img/about/about-img.jpg" alt="Image">
                            <div class="about-card">
                                <i class="las la-gem"></i>
                                <h3> <span> <?php echo e(__("msg.more_than")); ?></span>10</h3>
                                <p><?php echo e(__("msg.years_of_experince")); ?> </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
        <?php else: ?>
            
    
    
    
    
    
    
        <div class="about-area ptb-100">
            <div class="container" dir="ltr">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-text">
                            <span><?php echo e(__("msg.who_is_us")); ?></span>
                            <h3><?php echo e(__("msg.who_is_us_h")); ?> </h3>
                             
                            <p>
                                <?php echo e(__("msg.who_is_us_h1")); ?>

                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-img">
                            <img src="assets/img/about/about-img.jpg" alt="Image">
                            <div class="about-card">
                                <i class="las la-gem"></i>
                                <h3> <span> <?php echo e(__("msg.more_than")); ?></span>10</h3>
                                <p><?php echo e(__("msg.years_of_experince")); ?> </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
    
    
    
    
        <?php endif; ?>
        
        
        
    </div>
    
   <?php /**PATH C:\wamp4\www\wmc_ws\resources\views/includes/about.blade.php ENDPATH**/ ?>