<div class="navbar-area fixed-top">
    <div class="eoda-responsive-nav">
        <div class="container">
            <div class="eoda-responsive-menu">
                <div class="logo">
                    <a>
                        <img src="assets/img/logo.png" alt="logo">
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="eoda-nav">
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light">
                <a class="navbar-brand" href="index.html">
                    <img src="assets/img/logo.png" alt="logo">


                    
                </a>

                
                <div class="collapse navbar-collapse mean-menu" >
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item">

                            <a href="<?php echo e(url('/')); ?>" class="nav-link active">
                                <?php echo e(__("msg.main")); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(url('about')); ?>" class="nav-link">
                                <?php echo e(__("msg.the_window")); ?>

                            </a>
                        </li>

                        <li class="nav-item">

                            <a href="<?php echo e(url('services')); ?>" class="nav-link">
                                <?php echo e(__("msg.services")); ?>

                            </a>

                        </li>

                       
        
                        <li class="nav-item">
                            <a href="<?php echo e(url('all_stories')); ?>" class="nav-link">
                                <?php echo e(__("msg.work")); ?>

                            </a>

                        </li>
                       
                        <li class="nav-item">
                            <a href="<?php echo e(url('contact')); ?>" class="nav-link"
                            
                            
                            >
                            <?php echo e(__("msg.call_us")); ?>

                        </a>
                        </li>


                        <li class="nav-item">
                           
                        <br>
                      
                            <div>
                                <select onchange="changeLanguage(this.value)" >
       
                                   <option <?php echo e(session()->has('lang_code')?(session()->get('lang_code')=='ar'?'selected':''):''); ?> value="ar">عربي</option>
                                   <option <?php echo e(session()->has('lang_code')?(session()->get('lang_code')=='en'?'selected':''):''); ?> value="en">English</option>
                      
                               </select>
                           </div>

                        </li>
                        <!--<li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link search-box">
                                <i class="las la-search"></i>
                            </a>
                        </li>-->
                       
                        <li class="nav-btn">
                            <a href="https://api.whatsapp.com/send?phone=+<?php echo e(config('app.phn','no')); ?>" class="default-btn-two">  <?php echo e(__("msg.get_offer")); ?>  </a>
                        </li>
                    </ul>
                    
                </div>
            </nav>
        </div>
    </div>
</div>


<?php /**PATH C:\wamp4\www\wmc_ws\resources\views/includes/en/nav.blade.php ENDPATH**/ ?>